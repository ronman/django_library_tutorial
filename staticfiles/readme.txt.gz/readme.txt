Why this file is here:
"Git does not support empty file directories, so you will have to create a 
file inside that directory as well."
See https://devcenter.heroku.com/articles/django-assets
